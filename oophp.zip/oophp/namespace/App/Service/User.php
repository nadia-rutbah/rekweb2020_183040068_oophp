<?php namespace App\Service;
class User {
	public function __construct(){
		echo "Ini adalah Class " . __CLASS__;
	}
}